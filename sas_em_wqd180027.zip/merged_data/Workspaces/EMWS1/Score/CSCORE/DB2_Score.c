/*------------------------------------------------------------
Copyright (C) 2003 SAS Institute, Inc. All rights reserved.
 
Notice:
  The following permissions are granted provided that the
  above copyright and this notice appear in the code and
  any related documentation. Permission to copy, modify
  and distribute the C language source code generated using
  or distributed with SAS Enterprise Miner C Scoring software
  and any executables derived from such source code is
  limited to customers of SAS Institute with a valid license
  for SAS Enterprise Miner C Scoring software. Any distribution
  of such executables or source code shall be on an "AS IS"
  basis without warranty of any kind.  SAS and all other SAS
  Institute. Inc. product and service names are registered
  trademarks or trademarks of SAS Institute Inc. in the USA
  and other countries. Except as contained in this notice,
  the name of the SAS Institute, SAS Enterprise Miner and
  SAS Enterprise Miner C Scoring software shall not be used in
  the advertising or promotion of products or services without
  prior written authorization from SAS Institute Inc.
------------------------------------------------------------*/
 
/*--- start generated code ---*/ 
 
/*------------------------------------------------------------------
 *------------------------------------------------------------------
 * This section contains the functions to support scoring using 
 * DB2 User Defined Functions.
 *  
 * The AIX Compile command might look like:
 *    xlc -G -q32 -qlanglvl=ansi -lm -L/usr/lib -I/usr/lpp/db2_07_01/include -o cscoreudf.lib Score.c 
 *  
 *------------------------------------------------------------------
 * The DB2 SQL commands to register each of these functions might look like:
 * 
 *    CREATE FUNCTION <db_functionname>(DOUBLE    ) \ 
 *    RETURNS <type of outvar DOUBLE/VARCHAR> \ 
 *    FENCED  \ 
 *    NULL CALL NO SCRATCHPAD NO FINAL CALL NO DBINFO \
 *    DETERMINISTIC NO SQL NO EXTERNAL ACTION \ 
 *    LANGUAGE C PARAMETER STYLE DB2SQL \ 
 *    EXTERNAL NAME '</insert/db2server/accessible/path/libname!entrypoint>'
 *  
 *------------------------------------------------------------------
 * The DB2 SQL to invoke these functions might look like:
 * 
 *    <db_functionname>( BRENTCRUDE ) 
 * 
 *------------------------------------------------------------------
 *-----------------------------------------------------------------*/
 
#include <stddef.h>
#include <string.h>
#include <sqludf.h>
#include <sqlca.h>
#include <sqlda.h>
#include "csparm.h"
#ifdef __cplusplus
extern "C"
#endif
 
   extern unsigned char NaN[8];
#define MISSING  (*((double *)NaN))
#define missingn(a) nmiss(1, a)
 
extern char*  strncpyn(char*, size_t, char*);
extern void   score ( PARM *indata, PARM *outdata );
extern int    nmiss(int, ...);
extern int    missingc( char*);
 
#define csInSize 1
#define csOutSize 14
 
#define BRENTCRUDE       indata[0].data.fnum
#define EM_CLASSIFICATION       outdata[0].data.str
#define EM_EVENTPROBABILITY       outdata[1].data.fnum
#define EM_PROBABILITY       outdata[2].data.fnum
#define EM_SEGMENT       outdata[3].data.fnum
#define I_AIRASIA_TGT       outdata[4].data.str
#define P_AIRASIA_TGT0       outdata[5].data.fnum
#define P_AIRASIA_TGT1       outdata[6].data.fnum
#define Q_AIRASIA_TGT0       outdata[7].data.fnum
#define Q_AIRASIA_TGT1       outdata[8].data.fnum
#define U_AIRASIA_TGT       outdata[9].data.fnum
#define V_AIRASIA_TGT0       outdata[10].data.fnum
#define V_AIRASIA_TGT1       outdata[11].data.fnum
#define _NODE_       outdata[12].data.fnum
#define _WARN_       outdata[13].data.str
 
 
/*----------------------------------------------------------------
 *----------------------------------------------------------------
 * The load_indata_vec function is used by each of the UDFs to 
 * load the input vector of arguments for the score function.
 *----------------------------------------------------------------
 *--------------------------------------------------------------*/
PARM* load_indata_vec( PARM* indata,
                       SQLUDF_DOUBLE*  db_BRENTCRUDE,
                       SQLUDF_NULLIND* db_BRENTCRUDE_nullind) {
 /*----------------------------------------------------------------
  *  If null input from DB2, set the input value to missing
  *--------------------------------------------------------------*/
    
   if (*db_BRENTCRUDE_nullind < 0)
      BRENTCRUDE = MISSING;
   else
      BRENTCRUDE = *db_BRENTCRUDE;
    
   return indata;
}
 
/*----------------------------------------------------------------
 *----------------------------------------------------------------
 * This function calls the Enterprise Miner generated C scoring   
 * function and returns the calculated value of EM_CLASSIFICATION               
 *----------------------------------------------------------------
 *---------------------------------------------------------------*/
void SQL_API_FN udf_EM_CLASSIFICATION(
      SQLUDF_DOUBLE*  db_BRENTCRUDE,
      SQLUDF_VARCHAR* db_outvar,
      SQLUDF_NULLIND* db_BRENTCRUDE_nullind,
      SQLUDF_NULLIND* db_outvar_nullind,
      /*** UDF always-present (trailing) input arguments ***/
      SQLUDF_TRAIL_ARGS_ALL)
{
   PARM indata [1];
    
   PARM outdata [14];
   char udf_EM_CLASSIFICATION[33];
   char udf_I_AIRASIA_TGT[13];
   char udf__WARN_[5];
    
   /*----------------------------------------------------------------------
    *  clear and load the input vector for the score function
    *---------------------------------------------------------------------*/
   memset(indata,0,sizeof(PARM)*csInSize);
    
    
   load_indata_vec(indata,
                 db_BRENTCRUDE,
                 db_BRENTCRUDE_nullind);
                  
   /*---------------------------------------------------------------------
    *  clear and load the output vector for the score function
    *---------------------------------------------------------------------*/
   memset(outdata,0,sizeof(PARM)*csOutSize);
   EM_CLASSIFICATION = udf_EM_CLASSIFICATION;
   memset(EM_CLASSIFICATION,0,sizeof(char)*33);
   I_AIRASIA_TGT = udf_I_AIRASIA_TGT;
   memset(I_AIRASIA_TGT,0,sizeof(char)*13);
   _WARN_ = udf__WARN_;
   memset(_WARN_,0,sizeof(char)*5);
    
   /* invoke Enterprise Miner C scoring function */
   score(indata, outdata);
    
   /* handle output from score function */ 
   if (missingc(EM_CLASSIFICATION))
   {
      strcpy(db_outvar, " ");
      *db_outvar_nullind = -1;
   }
   else
   {
      strcpy(db_outvar, EM_CLASSIFICATION);
      *db_outvar_nullind = 0;
   }
    
   return;
}
 
/*----------------------------------------------------------------
 *----------------------------------------------------------------
 * This function calls the Enterprise Miner generated C scoring   
 * function and returns the calculated value of EM_EVENTPROBABILITY             
 *----------------------------------------------------------------
 *---------------------------------------------------------------*/
void SQL_API_FN udf_EM_EVENTPROBABILITY(
      SQLUDF_DOUBLE*  db_BRENTCRUDE,
      SQLUDF_DOUBLE*  db_outvar,
      SQLUDF_NULLIND* db_BRENTCRUDE_nullind,
      SQLUDF_NULLIND* db_outvar_nullind,
      /*** UDF always-present (trailing) input arguments ***/
      SQLUDF_TRAIL_ARGS_ALL)
{
   PARM indata [1];
    
   PARM outdata [14];
   char udf_EM_CLASSIFICATION[33];
   char udf_I_AIRASIA_TGT[13];
   char udf__WARN_[5];
    
   /*----------------------------------------------------------------------
    *  clear and load the input vector for the score function
    *---------------------------------------------------------------------*/
   memset(indata,0,sizeof(PARM)*csInSize);
    
    
   load_indata_vec(indata,
                 db_BRENTCRUDE,
                 db_BRENTCRUDE_nullind);
                  
   /*---------------------------------------------------------------------
    *  clear and load the output vector for the score function
    *---------------------------------------------------------------------*/
   memset(outdata,0,sizeof(PARM)*csOutSize);
   EM_CLASSIFICATION = udf_EM_CLASSIFICATION;
   memset(EM_CLASSIFICATION,0,sizeof(char)*33);
   I_AIRASIA_TGT = udf_I_AIRASIA_TGT;
   memset(I_AIRASIA_TGT,0,sizeof(char)*13);
   _WARN_ = udf__WARN_;
   memset(_WARN_,0,sizeof(char)*5);
    
   /* invoke Enterprise Miner C scoring function */
   score(indata, outdata);
    
   /* handle output from score function */ 
   if (missingn(EM_EVENTPROBABILITY))
   {
      *db_outvar = 0;
      *db_outvar_nullind = -1;
   }
   else
   {
      *db_outvar = EM_EVENTPROBABILITY;
      *db_outvar_nullind = 0;
   }
    
   return;
}
 
/*----------------------------------------------------------------
 *----------------------------------------------------------------
 * This function calls the Enterprise Miner generated C scoring   
 * function and returns the calculated value of EM_PROBABILITY                  
 *----------------------------------------------------------------
 *---------------------------------------------------------------*/
void SQL_API_FN udf_EM_PROBABILITY(
      SQLUDF_DOUBLE*  db_BRENTCRUDE,
      SQLUDF_DOUBLE*  db_outvar,
      SQLUDF_NULLIND* db_BRENTCRUDE_nullind,
      SQLUDF_NULLIND* db_outvar_nullind,
      /*** UDF always-present (trailing) input arguments ***/
      SQLUDF_TRAIL_ARGS_ALL)
{
   PARM indata [1];
    
   PARM outdata [14];
   char udf_EM_CLASSIFICATION[33];
   char udf_I_AIRASIA_TGT[13];
   char udf__WARN_[5];
    
   /*----------------------------------------------------------------------
    *  clear and load the input vector for the score function
    *---------------------------------------------------------------------*/
   memset(indata,0,sizeof(PARM)*csInSize);
    
    
   load_indata_vec(indata,
                 db_BRENTCRUDE,
                 db_BRENTCRUDE_nullind);
                  
   /*---------------------------------------------------------------------
    *  clear and load the output vector for the score function
    *---------------------------------------------------------------------*/
   memset(outdata,0,sizeof(PARM)*csOutSize);
   EM_CLASSIFICATION = udf_EM_CLASSIFICATION;
   memset(EM_CLASSIFICATION,0,sizeof(char)*33);
   I_AIRASIA_TGT = udf_I_AIRASIA_TGT;
   memset(I_AIRASIA_TGT,0,sizeof(char)*13);
   _WARN_ = udf__WARN_;
   memset(_WARN_,0,sizeof(char)*5);
    
   /* invoke Enterprise Miner C scoring function */
   score(indata, outdata);
    
   /* handle output from score function */ 
   if (missingn(EM_PROBABILITY))
   {
      *db_outvar = 0;
      *db_outvar_nullind = -1;
   }
   else
   {
      *db_outvar = EM_PROBABILITY;
      *db_outvar_nullind = 0;
   }
    
   return;
}
 
/*----------------------------------------------------------------
 *----------------------------------------------------------------
 * This function calls the Enterprise Miner generated C scoring   
 * function and returns the calculated value of EM_SEGMENT                      
 *----------------------------------------------------------------
 *---------------------------------------------------------------*/
void SQL_API_FN udf_EM_SEGMENT(
      SQLUDF_DOUBLE*  db_BRENTCRUDE,
      SQLUDF_DOUBLE*  db_outvar,
      SQLUDF_NULLIND* db_BRENTCRUDE_nullind,
      SQLUDF_NULLIND* db_outvar_nullind,
      /*** UDF always-present (trailing) input arguments ***/
      SQLUDF_TRAIL_ARGS_ALL)
{
   PARM indata [1];
    
   PARM outdata [14];
   char udf_EM_CLASSIFICATION[33];
   char udf_I_AIRASIA_TGT[13];
   char udf__WARN_[5];
    
   /*----------------------------------------------------------------------
    *  clear and load the input vector for the score function
    *---------------------------------------------------------------------*/
   memset(indata,0,sizeof(PARM)*csInSize);
    
    
   load_indata_vec(indata,
                 db_BRENTCRUDE,
                 db_BRENTCRUDE_nullind);
                  
   /*---------------------------------------------------------------------
    *  clear and load the output vector for the score function
    *---------------------------------------------------------------------*/
   memset(outdata,0,sizeof(PARM)*csOutSize);
   EM_CLASSIFICATION = udf_EM_CLASSIFICATION;
   memset(EM_CLASSIFICATION,0,sizeof(char)*33);
   I_AIRASIA_TGT = udf_I_AIRASIA_TGT;
   memset(I_AIRASIA_TGT,0,sizeof(char)*13);
   _WARN_ = udf__WARN_;
   memset(_WARN_,0,sizeof(char)*5);
    
   /* invoke Enterprise Miner C scoring function */
   score(indata, outdata);
    
   /* handle output from score function */ 
   if (missingn(EM_SEGMENT))
   {
      *db_outvar = 0;
      *db_outvar_nullind = -1;
   }
   else
   {
      *db_outvar = EM_SEGMENT;
      *db_outvar_nullind = 0;
   }
    
   return;
}
 
/*----------------------------------------------------------------
 *----------------------------------------------------------------
 * This function calls the Enterprise Miner generated C scoring   
 * function and returns the calculated value of I_AIRASIA_TGT                   
 *----------------------------------------------------------------
 *---------------------------------------------------------------*/
void SQL_API_FN udf_I_AIRASIA_TGT(
      SQLUDF_DOUBLE*  db_BRENTCRUDE,
      SQLUDF_VARCHAR* db_outvar,
      SQLUDF_NULLIND* db_BRENTCRUDE_nullind,
      SQLUDF_NULLIND* db_outvar_nullind,
      /*** UDF always-present (trailing) input arguments ***/
      SQLUDF_TRAIL_ARGS_ALL)
{
   PARM indata [1];
    
   PARM outdata [14];
   char udf_EM_CLASSIFICATION[33];
   char udf_I_AIRASIA_TGT[13];
   char udf__WARN_[5];
    
   /*----------------------------------------------------------------------
    *  clear and load the input vector for the score function
    *---------------------------------------------------------------------*/
   memset(indata,0,sizeof(PARM)*csInSize);
    
    
   load_indata_vec(indata,
                 db_BRENTCRUDE,
                 db_BRENTCRUDE_nullind);
                  
   /*---------------------------------------------------------------------
    *  clear and load the output vector for the score function
    *---------------------------------------------------------------------*/
   memset(outdata,0,sizeof(PARM)*csOutSize);
   EM_CLASSIFICATION = udf_EM_CLASSIFICATION;
   memset(EM_CLASSIFICATION,0,sizeof(char)*33);
   I_AIRASIA_TGT = udf_I_AIRASIA_TGT;
   memset(I_AIRASIA_TGT,0,sizeof(char)*13);
   _WARN_ = udf__WARN_;
   memset(_WARN_,0,sizeof(char)*5);
    
   /* invoke Enterprise Miner C scoring function */
   score(indata, outdata);
    
   /* handle output from score function */ 
   if (missingc(I_AIRASIA_TGT))
   {
      strcpy(db_outvar, " ");
      *db_outvar_nullind = -1;
   }
   else
   {
      strcpy(db_outvar, I_AIRASIA_TGT);
      *db_outvar_nullind = 0;
   }
    
   return;
}
 
/*----------------------------------------------------------------
 *----------------------------------------------------------------
 * This function calls the Enterprise Miner generated C scoring   
 * function and returns the calculated value of P_AIRASIA_TGT0                  
 *----------------------------------------------------------------
 *---------------------------------------------------------------*/
void SQL_API_FN udf_P_AIRASIA_TGT0(
      SQLUDF_DOUBLE*  db_BRENTCRUDE,
      SQLUDF_DOUBLE*  db_outvar,
      SQLUDF_NULLIND* db_BRENTCRUDE_nullind,
      SQLUDF_NULLIND* db_outvar_nullind,
      /*** UDF always-present (trailing) input arguments ***/
      SQLUDF_TRAIL_ARGS_ALL)
{
   PARM indata [1];
    
   PARM outdata [14];
   char udf_EM_CLASSIFICATION[33];
   char udf_I_AIRASIA_TGT[13];
   char udf__WARN_[5];
    
   /*----------------------------------------------------------------------
    *  clear and load the input vector for the score function
    *---------------------------------------------------------------------*/
   memset(indata,0,sizeof(PARM)*csInSize);
    
    
   load_indata_vec(indata,
                 db_BRENTCRUDE,
                 db_BRENTCRUDE_nullind);
                  
   /*---------------------------------------------------------------------
    *  clear and load the output vector for the score function
    *---------------------------------------------------------------------*/
   memset(outdata,0,sizeof(PARM)*csOutSize);
   EM_CLASSIFICATION = udf_EM_CLASSIFICATION;
   memset(EM_CLASSIFICATION,0,sizeof(char)*33);
   I_AIRASIA_TGT = udf_I_AIRASIA_TGT;
   memset(I_AIRASIA_TGT,0,sizeof(char)*13);
   _WARN_ = udf__WARN_;
   memset(_WARN_,0,sizeof(char)*5);
    
   /* invoke Enterprise Miner C scoring function */
   score(indata, outdata);
    
   /* handle output from score function */ 
   if (missingn(P_AIRASIA_TGT0))
   {
      *db_outvar = 0;
      *db_outvar_nullind = -1;
   }
   else
   {
      *db_outvar = P_AIRASIA_TGT0;
      *db_outvar_nullind = 0;
   }
    
   return;
}
 
/*----------------------------------------------------------------
 *----------------------------------------------------------------
 * This function calls the Enterprise Miner generated C scoring   
 * function and returns the calculated value of P_AIRASIA_TGT1                  
 *----------------------------------------------------------------
 *---------------------------------------------------------------*/
void SQL_API_FN udf_P_AIRASIA_TGT1(
      SQLUDF_DOUBLE*  db_BRENTCRUDE,
      SQLUDF_DOUBLE*  db_outvar,
      SQLUDF_NULLIND* db_BRENTCRUDE_nullind,
      SQLUDF_NULLIND* db_outvar_nullind,
      /*** UDF always-present (trailing) input arguments ***/
      SQLUDF_TRAIL_ARGS_ALL)
{
   PARM indata [1];
    
   PARM outdata [14];
   char udf_EM_CLASSIFICATION[33];
   char udf_I_AIRASIA_TGT[13];
   char udf__WARN_[5];
    
   /*----------------------------------------------------------------------
    *  clear and load the input vector for the score function
    *---------------------------------------------------------------------*/
   memset(indata,0,sizeof(PARM)*csInSize);
    
    
   load_indata_vec(indata,
                 db_BRENTCRUDE,
                 db_BRENTCRUDE_nullind);
                  
   /*---------------------------------------------------------------------
    *  clear and load the output vector for the score function
    *---------------------------------------------------------------------*/
   memset(outdata,0,sizeof(PARM)*csOutSize);
   EM_CLASSIFICATION = udf_EM_CLASSIFICATION;
   memset(EM_CLASSIFICATION,0,sizeof(char)*33);
   I_AIRASIA_TGT = udf_I_AIRASIA_TGT;
   memset(I_AIRASIA_TGT,0,sizeof(char)*13);
   _WARN_ = udf__WARN_;
   memset(_WARN_,0,sizeof(char)*5);
    
   /* invoke Enterprise Miner C scoring function */
   score(indata, outdata);
    
   /* handle output from score function */ 
   if (missingn(P_AIRASIA_TGT1))
   {
      *db_outvar = 0;
      *db_outvar_nullind = -1;
   }
   else
   {
      *db_outvar = P_AIRASIA_TGT1;
      *db_outvar_nullind = 0;
   }
    
   return;
}
 
/*----------------------------------------------------------------
 *----------------------------------------------------------------
 * This function calls the Enterprise Miner generated C scoring   
 * function and returns the calculated value of U_AIRASIA_TGT                   
 *----------------------------------------------------------------
 *---------------------------------------------------------------*/
void SQL_API_FN udf_U_AIRASIA_TGT(
      SQLUDF_DOUBLE*  db_BRENTCRUDE,
      SQLUDF_DOUBLE*  db_outvar,
      SQLUDF_NULLIND* db_BRENTCRUDE_nullind,
      SQLUDF_NULLIND* db_outvar_nullind,
      /*** UDF always-present (trailing) input arguments ***/
      SQLUDF_TRAIL_ARGS_ALL)
{
   PARM indata [1];
    
   PARM outdata [14];
   char udf_EM_CLASSIFICATION[33];
   char udf_I_AIRASIA_TGT[13];
   char udf__WARN_[5];
    
   /*----------------------------------------------------------------------
    *  clear and load the input vector for the score function
    *---------------------------------------------------------------------*/
   memset(indata,0,sizeof(PARM)*csInSize);
    
    
   load_indata_vec(indata,
                 db_BRENTCRUDE,
                 db_BRENTCRUDE_nullind);
                  
   /*---------------------------------------------------------------------
    *  clear and load the output vector for the score function
    *---------------------------------------------------------------------*/
   memset(outdata,0,sizeof(PARM)*csOutSize);
   EM_CLASSIFICATION = udf_EM_CLASSIFICATION;
   memset(EM_CLASSIFICATION,0,sizeof(char)*33);
   I_AIRASIA_TGT = udf_I_AIRASIA_TGT;
   memset(I_AIRASIA_TGT,0,sizeof(char)*13);
   _WARN_ = udf__WARN_;
   memset(_WARN_,0,sizeof(char)*5);
    
   /* invoke Enterprise Miner C scoring function */
   score(indata, outdata);
    
   /* handle output from score function */ 
   if (missingn(U_AIRASIA_TGT))
   {
      *db_outvar = 0;
      *db_outvar_nullind = -1;
   }
   else
   {
      *db_outvar = U_AIRASIA_TGT;
      *db_outvar_nullind = 0;
   }
    
   return;
}
 
/*----------------------------------------------------------------
 *----------------------------------------------------------------
 * This function calls the Enterprise Miner generated C scoring   
 * function and returns the calculated value of _NODE_                          
 *----------------------------------------------------------------
 *---------------------------------------------------------------*/
void SQL_API_FN udf__NODE_(
      SQLUDF_DOUBLE*  db_BRENTCRUDE,
      SQLUDF_DOUBLE*  db_outvar,
      SQLUDF_NULLIND* db_BRENTCRUDE_nullind,
      SQLUDF_NULLIND* db_outvar_nullind,
      /*** UDF always-present (trailing) input arguments ***/
      SQLUDF_TRAIL_ARGS_ALL)
{
   PARM indata [1];
    
   PARM outdata [14];
   char udf_EM_CLASSIFICATION[33];
   char udf_I_AIRASIA_TGT[13];
   char udf__WARN_[5];
    
   /*----------------------------------------------------------------------
    *  clear and load the input vector for the score function
    *---------------------------------------------------------------------*/
   memset(indata,0,sizeof(PARM)*csInSize);
    
    
   load_indata_vec(indata,
                 db_BRENTCRUDE,
                 db_BRENTCRUDE_nullind);
                  
   /*---------------------------------------------------------------------
    *  clear and load the output vector for the score function
    *---------------------------------------------------------------------*/
   memset(outdata,0,sizeof(PARM)*csOutSize);
   EM_CLASSIFICATION = udf_EM_CLASSIFICATION;
   memset(EM_CLASSIFICATION,0,sizeof(char)*33);
   I_AIRASIA_TGT = udf_I_AIRASIA_TGT;
   memset(I_AIRASIA_TGT,0,sizeof(char)*13);
   _WARN_ = udf__WARN_;
   memset(_WARN_,0,sizeof(char)*5);
    
   /* invoke Enterprise Miner C scoring function */
   score(indata, outdata);
    
   /* handle output from score function */ 
   if (missingn(_NODE_))
   {
      *db_outvar = 0;
      *db_outvar_nullind = -1;
   }
   else
   {
      *db_outvar = _NODE_;
      *db_outvar_nullind = 0;
   }
    
   return;
}
 
/*----------------------------------------------------------------
 *----------------------------------------------------------------
 * This function calls the Enterprise Miner generated C scoring   
 * function and returns the calculated value of _WARN_                          
 *----------------------------------------------------------------
 *---------------------------------------------------------------*/
void SQL_API_FN udf__WARN_(
      SQLUDF_DOUBLE*  db_BRENTCRUDE,
      SQLUDF_VARCHAR* db_outvar,
      SQLUDF_NULLIND* db_BRENTCRUDE_nullind,
      SQLUDF_NULLIND* db_outvar_nullind,
      /*** UDF always-present (trailing) input arguments ***/
      SQLUDF_TRAIL_ARGS_ALL)
{
   PARM indata [1];
    
   PARM outdata [14];
   char udf_EM_CLASSIFICATION[33];
   char udf_I_AIRASIA_TGT[13];
   char udf__WARN_[5];
    
   /*----------------------------------------------------------------------
    *  clear and load the input vector for the score function
    *---------------------------------------------------------------------*/
   memset(indata,0,sizeof(PARM)*csInSize);
    
    
   load_indata_vec(indata,
                 db_BRENTCRUDE,
                 db_BRENTCRUDE_nullind);
                  
   /*---------------------------------------------------------------------
    *  clear and load the output vector for the score function
    *---------------------------------------------------------------------*/
   memset(outdata,0,sizeof(PARM)*csOutSize);
   EM_CLASSIFICATION = udf_EM_CLASSIFICATION;
   memset(EM_CLASSIFICATION,0,sizeof(char)*33);
   I_AIRASIA_TGT = udf_I_AIRASIA_TGT;
   memset(I_AIRASIA_TGT,0,sizeof(char)*13);
   _WARN_ = udf__WARN_;
   memset(_WARN_,0,sizeof(char)*5);
    
   /* invoke Enterprise Miner C scoring function */
   score(indata, outdata);
    
   /* handle output from score function */ 
   if (missingc(_WARN_))
   {
      strcpy(db_outvar, " ");
      *db_outvar_nullind = -1;
   }
   else
   {
      strcpy(db_outvar, _WARN_);
      *db_outvar_nullind = 0;
   }
    
   return;
}
