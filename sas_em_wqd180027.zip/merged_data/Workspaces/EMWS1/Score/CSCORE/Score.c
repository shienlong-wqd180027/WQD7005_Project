/*------------------------------------------------------------
Copyright (C) 2000 SAS Institute, Inc. All rights reserved.

Notice:
  The following permissions are granted provided that the
  above copyright and this notice appear in the code and
  any related documentation. Permission to copy, modify
  and distribute the C language source code generated using
  or distributed with SAS Enterprise Miner C Scoring software
  and any executables derived from such source code is
  limited to customers of SAS Institute with a valid license
  for SAS Enterprise Miner C Scoring software. Any distribution
  of such executables or source code shall be on an "AS IS"
  basis without warranty of any kind.  SAS and all other SAS
  Institute. Inc. product and service names are registered
  trademarks or trademarks of SAS Institute Inc. in the USA
  and other countries. Except as contained in this notice,
  the name of the SAS Institute, SAS Enterprise Miner and
  SAS Enterprise Miner C Scoring software shall not be used in
  the advertising or promotion of products or services without
  prior written authorization from SAS Institute Inc.
------------------------------------------------------------*/

/*--- start generated code ---*/

#include <math.h>
#include <string.h>
#include <memory.h>
#include <ctype.h>

#include "cscore.h"

#include "csparm.h"

#define BRENTCRUDE       indata[0].data.fnum
#define EM_CLASSIFICATION       outdata[0].data.str
#define EM_EVENTPROBABILITY       outdata[1].data.fnum
#define EM_PROBABILITY       outdata[2].data.fnum
#define EM_SEGMENT       outdata[3].data.fnum
#define I_AIRASIA_TGT       outdata[4].data.str
#define P_AIRASIA_TGT0       outdata[5].data.fnum
#define P_AIRASIA_TGT1       outdata[6].data.fnum
#define Q_AIRASIA_TGT0       outdata[7].data.fnum
#define Q_AIRASIA_TGT1       outdata[8].data.fnum
#define U_AIRASIA_TGT       outdata[9].data.fnum
#define V_AIRASIA_TGT0       outdata[10].data.fnum
#define V_AIRASIA_TGT1       outdata[11].data.fnum
#define _NODE_       outdata[12].data.fnum
#define _WARN_       outdata[13].data.str

SFDKeyWords void score ( PARM *indata, PARM *outdata )
{

/*--- Auto Variables ---*/
      char   _ARBFMT_12[13];
      double _LEAF_;

      strcpy(_WARN_,"    ");

   /*--- initialize stand alone formats library ---*/
   #if FMTLIB == 1
      xfinit();
   #endif

   /*------------------------------------------------------------**/
   /* em score code*/
   /*------------------------------------------------------------**/
   /*------------------------------------------------------------**/
   /* tool: extension class*/
   /* type: sample*/
   /* node: fimport*/
   /*------------------------------------------------------------**/
   /*------------------------------------------------------------**/
   /* tool: partition class*/
   /* type: sample*/
   /* node: part3*/
   /*------------------------------------------------------------**/
   /*------------------------------------------------------------**/
   /* tool: extension class*/
   /* type: model*/
   /* node: tree3*/
   /*------------------------------------------------------------**/
   /****************************************************************/
   /*****             decision tree scoring code             *******/
   /****************************************************************/
   /*****         lengths of new character variables         *******/
/*****              labels for new variables              *******/
/*****      temporary variables for formatted values      *******/
    strncpyn( _ARBFMT_12, 12," ");
   /* initialize to avoid warning. */
   /*****             assign observation to node             *******/
   if (! missingn(BRENTCRUDE) && 71.435 <= BRENTCRUDE)
   {
      _NODE_ = 3.0;
      _LEAF_ = 2.0;
      P_AIRASIA_TGT0 = 0.09090909090909;
      P_AIRASIA_TGT1 = 0.9090909090909;
      Q_AIRASIA_TGT0 = 0.09090909090909;
      Q_AIRASIA_TGT1 = 0.9090909090909;
      V_AIRASIA_TGT0 = 0.0;
      V_AIRASIA_TGT1 = 1.0;
       strncpyn( I_AIRASIA_TGT, 12,"1");
      U_AIRASIA_TGT = 1.0;
   }
   else {
      _NODE_ = 2.0;
      _LEAF_ = 1.0;
      P_AIRASIA_TGT0 = 0.58333333333333;
      P_AIRASIA_TGT1 = 0.41666666666666;
      Q_AIRASIA_TGT0 = 0.58333333333333;
      Q_AIRASIA_TGT1 = 0.41666666666666;
      V_AIRASIA_TGT0 = 0.5625;
      V_AIRASIA_TGT1 = 0.4375;
       strncpyn( I_AIRASIA_TGT, 12,"0");
      U_AIRASIA_TGT = 0.0;
   }
   /****************************************************************/
   /*****          end of decision tree scoring code         *******/
   /****************************************************************/
/*------------------------------------------------------------**/
   /* tool: model compare class*/
   /* type: assess*/
   /* node: mdlcomp*/
   /*------------------------------------------------------------**/
   /*------------------------------------------------------------**/
   /* tool: score node*/
   /* type: assess*/
   /* node: score*/
   /*------------------------------------------------------------**/
   /*------------------------------------------------------------**/
   /* score: creating fixed names*/
   /*------------------------------------------------------------**/
   EM_SEGMENT = _NODE_;
   EM_EVENTPROBABILITY = P_AIRASIA_TGT1;
   EM_PROBABILITY = nmax( 2     , P_AIRASIA_TGT1 , P_AIRASIA_TGT0);
    strncpyn( EM_CLASSIFICATION, 32, I_AIRASIA_TGT);



  return;

}
usrNbucket usrnBuckets[]={
/* not used */
{0,0,0,NULL,NULL,' ',0.0}
};

usrCbucket usrcBuckets[]={
/* not used */
{NULL, NULL, 0, NULL}

};
usrFormat usrnFormats[] = {
{"**unused**",0.0,0,0,0,-1,-1,0}
};
usrFormat usrcFormats[] = {
{"**unused**",0.0,0,0,0,-1,-1,0}
};
int usrNumNfmts = 0;
int usrNumCfmts = 0;
