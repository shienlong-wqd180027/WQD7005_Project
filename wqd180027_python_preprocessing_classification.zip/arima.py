import pandas as pd
import os
import matplotlib.pyplot as plt
from statsmodels.tsa.arima_model import ARIMA
from sklearn.metrics import mean_squared_error

os.chdir('C:/wqd180027')

# Load data into dataframe
df = pd.read_csv("output/merge_data_tgt_corr.csv",
                 index_col=0,
                 header=0,
                 parse_dates=[1],
                 squeeze=True)

# Length of dataset
len_df = len(df)

# Subset of stock data
df_sub = df[['Date','AIRASIA_cls']]

# Split training and test dataset by time
# X = df_sub.values
size = int(len(df_sub) * 0.66)
train = df_sub[0:size]
test = df_sub[size:len(df_sub)]
# train = df_sub[0:len_df-2]
# test = df_sub[len_df-2:]

# Plot line graph
plt.plot(df_sub['Date'], df_sub['AIRASIA_cls'])
plt.title('AIRASIA Close Price')
plt.show()

# fit model
model = ARIMA(train['AIRASIA_cls'], order=(5,1,0))
model_fit = model.fit(disp=0)
print(model_fit.summary())

# plot residual errors
residuals = pd.DataFrame(model_fit.resid)
residuals.plot()
plt.title('ARMA Fit Residual Error Plot')
plt.show()
residuals.plot(kind='kde')
plt.title('ARMA Fit Residual Error Density Plot')
plt.show()
print(residuals.describe())

history = [x for x in train['AIRASIA_cls']]
predictions = list()

# print predictions and expected values for test data
for t in range(len(test)):
    model = ARIMA(history, order=(5, 1, 0))
    model_fit = model.fit(disp=0)
    output = model_fit.forecast()
    yhat = output[0]
    predictions.append(yhat)
    obs = test.iloc[t,1]
    # obs = test[t]
    history.append(obs)
    print('predicted=%f, expected=%f' % (yhat, obs))
error = mean_squared_error(test.iloc[:,1], predictions)
print('Test MSE: %.3f' % error)
# plot
test.reset_index(drop=True, inplace=True) # Reset index, otherwise plots will be side by side.
plt.plot(test.iloc[:,1])
# plt.show()
# plt.plot(test)
plt.plot(predictions, color='red')
plt.show()


print("hello world")
