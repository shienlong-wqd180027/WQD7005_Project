# Data Cleaning part1
import pandas as pd
import os

# Set working directory
os.chdir('C:/wqd180027')

# Read CSV into dataframe
df_biznews=pd.read_csv("data/BusinessNews_.csv")
df_commod=pd.read_csv("data/Commodities_.csv")
df_Forum=pd.read_csv("data/ForumPosts_.csv")
df_Forex=pd.read_csv("data/MajorForex_.csv")
df_Indice=pd.read_csv("data/MajorIndices_.csv")
df_Stock=pd.read_csv("data/StockPrice_.csv")
df_Tweet=pd.read_csv("data/StocksTweetFeed_.csv")


# Take a look at data
print(df_biznews.head(5))
print(df_commod.head(5))
print(df_Forum.head(5))
print(df_Forex.head(5))
print(df_Indice.head(5))
print(df_Stock.head(5))
print(df_Tweet.head(5))

# Take a look at count of missing values
print(df_biznews.isnull().sum())
print(df_commod.isnull().sum())
print(df_Forum.isnull().sum())
print(df_Forex.isnull().sum())
print(df_Indice.isnull().sum())
print(df_Stock.isnull().sum())
print(df_Tweet.isnull().sum())

# Remove missing codes
df_biznews.dropna(subset=['Code'], inplace=True)
df_biznews.to_csv('data/BusinessNews_.csv')
print(df_biznews.isnull().sum())


# Pivot data
pivot_biznews = df_biznews.pivot_table(index='Date', columns='Code', values='Title', aggfunc=len, fill_value=0)
pivot_commod = df_commod.pivot(index='Date', columns='Symbol', values='LastPrice')
pivot_forum = df_Forum.pivot(index='Date', columns='Quote', values='Posts')
pivot_forex = df_Forex.pivot(index='UpdateDate', columns='CurrencyCode', values='UnitsPerMYR') # or MYRPerUnit
pivot_indice = df_Indice.pivot(index='Date', columns='Symbol', values='LastPrice')
pivot_stock = df_Stock.pivot(index='Date', columns='Quote', values='LastPrice')
pivot_stock_vol = df_Stock.pivot(index='Date', columns='Quote', values='Volume')
pivot_stock_chg = df_Stock.pivot(index='Date', columns='Quote', values='ChgPct')
# pivot_tweet = df_Tweet.pivot(index='Date', columns='Quote', values='LastPrice')

# Save pivots to CSV
pivot_biznews.to_csv('output/pivot_biznews.csv')
pivot_commod.to_csv('output/pivot_commod.csv')
pivot_forum.to_csv('output/pivot_forum.csv')
pivot_forex.to_csv('output/pivot_forex.csv')
pivot_indice.to_csv('output/pivot_indice.csv')
pivot_stock.to_csv('output/pivot_stock.csv')
pivot_stock_vol.to_csv('output/pivot_stock_vol.csv')
pivot_stock_chg.to_csv('output/pivot_stock_chg.csv')


# Total sum of missing values for each dataset
print(pivot_biznews.isnull().sum().sum())
print(pivot_commod.isnull().sum().sum())
print(pivot_forex.isnull().sum().sum()) #8
print(pivot_forum.isnull().sum().sum())
print(pivot_indice.isnull().sum().sum())
print(pivot_stock.isnull().sum().sum()) #311

# Save attributes and values of dataset with missing values
nullcol_forex = pivot_forex.columns[pivot_forex.isnull().any()]
nullcol_stock = pivot_stock.columns[pivot_stock.isnull().any()]
nullcol_forum = pivot_forum.columns[pivot_forum.isnull().any()]


# Print column fields with missing values
# print(nullcol_forex)
# print(nullcol_stock)
# print(nullcol_forum)

# Remove column fields with missing value
pivot_forex.drop(nullcol_forex, axis=1, inplace=True)

pivot_stock.drop(nullcol_stock, axis=1, inplace=True)
pivot_stock_slim = pivot_stock[['AIRASIA','SAPNRG','GETS','MYEG']]  # For this project, these 4 stocks were selected
pivot_stock_vol = pivot_stock_vol[['AIRASIA','SAPNRG','GETS','MYEG']]
pivot_stock_chg = pivot_stock_chg[['AIRASIA','SAPNRG','GETS','MYEG']]
pivot_stock.reset_index(level=0, inplace=True)  # Reset index to column
pivot_stock_slim.reset_index(level=0, inplace=True)
pivot_stock.to_csv('output/pivot_stock.csv')
pivot_stock_slim.to_csv('output/pivot_stock_slim.csv')


# Keep relevant fields for analysis. Discard the rest
keep_indices = ['^STI', '^HSI', '000001.SS', '^GSPC', '^DJI', '^IXIC', '^N225', '^KLSE']
pivot_indice_slim = pivot_indice[keep_indices]
pivot_indice_slim.reset_index(level=0, inplace=True)  # Reset index to column
pivot_indice_slim.rename(columns={'^STI': 'STI',
                                  '^HSI': 'HSI',
                                  '000001.SS': 'SSE',
                                  '^GSPC': 'SP500',
                                  '^DJI': 'DJI',
                                  '^IXIC': 'NDAQ',
                                  '^N225': 'NIKKEI',
                                  '^KLSE': 'KLSE'}, inplace=True)
pivot_indice_slim.to_csv('output/pivot_indice_slim.csv')

keep_forex = ['CNY', 'SGD', 'USD', 'EUR', 'GBP', 'JPY']
pivot_forex_slim = pivot_forex[keep_forex]
pivot_forex_slim.reset_index(level=0, inplace=True)  # Reset index to column
pivot_forex_slim.rename(columns={"UpdateDate": "Date"}, inplace=True)
pivot_forex_slim.to_csv('output/pivot_forex_slim.csv')

keep_commod = ['GC=F', 'CL=F', 'BZ=F']
pivot_commod_slim = pivot_commod[keep_commod]
pivot_commod_slim.reset_index(level=0, inplace=True)  # Reset index to column
pivot_commod_slim.rename(columns={'GC=F':'Gold','CL=F':'CrudeOil','BZ=F':'BrentCrude'},inplace=True)
pivot_commod_slim.to_csv('output/pivot_commod_slim.csv')

# Rename UpdateDate to Date
# pivot_forex_slim = pivot_forex_slim.rename(columns={'UpdateDate':'Date'}, inplace=True)

# Merge dataframes
df_merge = pd.merge(pivot_stock_slim, pivot_stock_vol, on='Date', how='left', suffixes=('_cls','_vol'))
df_merge = pd.merge(df_merge, pivot_stock_chg, on='Date', how='left')
df_merge = pd.merge(df_merge, pivot_indice_slim, on='Date', how='left')
df_merge = pd.merge(df_merge, pivot_commod_slim, on='Date', how='left')
df_merge = pd.merge(df_merge, pivot_forex_slim, on='Date', how='left')
df_merge.to_csv('output/merge_data.csv')

print("Hello World")
