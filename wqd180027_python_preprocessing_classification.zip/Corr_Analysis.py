# Data Integration - Redundancy Analysis

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

# Set working directory
os.chdir('C:/wqd180027')

# Load data into dataframe
df = pd.read_csv("output/merge_data_tgt.csv", index_col=0)


# Correlation matrix
df.corr().to_csv('output/corr.csv')
corr = df.corr()

print(corr)

# Plot heatmap
sns.heatmap(corr,
        xticklabels=corr.columns,
        yticklabels=corr.columns)
plt.show()

# Nasdaq (NDAQ) and S&P500 (SP500) shows very high correlation - remove NDAQ
# Brent crude and crude oil shows very high correlation - remove crude oil

# Drop NDAQ and CrudeOil columns
drop_col = ['NDAQ', 'CrudeOil']
df.drop(drop_col, axis=1, inplace=True)

corr = df.corr()

# Replot heatmap
sns.heatmap(corr,
            xticklabels=corr.columns,
            yticklabels=corr.columns)
plt.show()

# Save latest data after drop column
corr.to_csv('output/corr.csv')
df.to_csv('output/merge_data_tgt_corr.csv')

print("Hello World")