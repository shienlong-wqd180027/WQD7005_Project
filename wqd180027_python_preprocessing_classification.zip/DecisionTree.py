# Predict up/down/nochange based on features
# need to install Graphviz on Windows (graphviz-2.38.msi) https://graphviz.gitlab.io/_pages/Download/Download_windows.html
import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.tree import export_graphviz
import subprocess
import os

# Set working directory
os.chdir('C:/wqd180027')

# Load data into dataframe
df = pd.read_csv("output/merge_data_tgt_corr.csv", index_col=0)

# Encode target values to integers
def encode_target(target_column):
    """Add column to df with integers for the target.

    Args
    ----
    df -- pandas DataFrame.
    target_column -- column to map to int, producing
                     new Target column.

    Returns
    -------
    df_mod -- modified DataFrame.
    targets -- list of target names.
    """
    df_mod = df.copy()
    targets = df_mod[target_column].unique()
    map_to_int = {name: n for n, name in enumerate(targets)}
    df_mod["Target"] = df_mod[target_column].replace(map_to_int)

    return


def visualize_tree(tree, feature_names):
    """Create tree png using graphviz.

    Args
    ----
    tree -- scikit-learn DecsisionTree.
    feature_names -- list of feature names.
    """
    with open("dt.dot", 'w') as f:
        export_graphviz(tree, out_file=f,
                        feature_names=feature_names)

    command = ["dot", "-Tpng", "dt.dot", "-o", "dt.png"]
    try:
        subprocess.check_call(command)
    except:
        exit("Could not run dot, ie graphviz, to "
             "produce visualization")




# encode_target('MYEG_tgt')

# Get names of feature columns
features = list(df.columns[1:-4])   # Do not take 'Date' and last 4 target columns as features
class_names = pd.factorize(df['AIRASIA_tgt'])

y = df['AIRASIA_tgt']
X = df[features]
dt = DecisionTreeClassifier(min_samples_split=20, random_state=99)
dt.fit(X, y)

visualize_tree(dt, features)


print("hello world")