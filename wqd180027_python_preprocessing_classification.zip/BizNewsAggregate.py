import pandas as pd
import numpy as np
import os

# Set working directory
os.chdir('C:/wqd180027')

# Read CSV into dataframe
df = pd.read_csv("data/BusinessNews_.csv", index_col=0)

# Drop redundant columns
i=[0,1,2,3,4,5,6,7,8,9,10]
df.drop(df.columns[i], axis=1, inplace=True)

aggr_df = df.groupby('Quote', as_index=False)['Date'].agg('count')
# aggr_df = pd.DataFrame(aggr_df, columns=['Code','Freq'])
aggr_df.columns = ["Quote", "Freq"]
aggr_df.to_csv('data/BizNewsAggr_.csv', index=False)

print("hello world")