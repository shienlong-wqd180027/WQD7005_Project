# Data Reduction - PCA on data after data integration (correlation)

import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
import os

# Set working directory
os.chdir('C:/wqd180027')

# Load data into dataframe
df = pd.read_csv("output/merge_data_tgt_corr.csv", index_col=0)

features = ['AIRASIA_cls','AIRASIA_vol','STI','HSI','SSE','SP500','DJI','NIKKEI','KLSE','Gold','BrentCrude','CNY','SGD','USD','EUR','GBP','JPY']


# Separating out the features
x = df.loc[:, features].values
# Separating out the target
y = df.loc[:,['AIRASIA_tgt']].values
# y = df.loc[:,['SAPNRG_tgt']].values
# Standardizing the features
x = StandardScaler().fit_transform(x)

pca = PCA(n_components=2)
principalComponents = pca.fit_transform(x)
principalDf = pd.DataFrame(data = principalComponents
             , columns = ['principal component 1', 'principal component 2'])

print(principalDf)


finalDf = pd.concat([principalDf, df[['AIRASIA_tgt']]], axis = 1)
# finalDf = pd.concat([principalDf, df[['SAPNRG_tgt']]], axis = 1)

finalDf.to_csv('output/AIRASIA_pca.csv')
# finalDf.to_csv('sapnrg_pca.csv')

fig = plt.figure(figsize = (8,8))
ax = fig.add_subplot(1,1,1)
ax.set_xlabel('Principal Component 1', fontsize = 15)
ax.set_ylabel('Principal Component 2', fontsize = 15)
ax.set_title('2 component PCA', fontsize = 20)

targets = [0, 1]
colors = ['r', 'g', 'b']
for target, color in zip(targets,colors):
    indicesToKeep = finalDf['AIRASIA_tgt'] == target
    ax.scatter(finalDf.loc[indicesToKeep, 'principal component 1']
               , finalDf.loc[indicesToKeep, 'principal component 2']
               , c = color
               , s = 50)
ax.legend(targets)
ax.grid()
plt.show()
print(pca.explained_variance_ratio_)

print("hello world")