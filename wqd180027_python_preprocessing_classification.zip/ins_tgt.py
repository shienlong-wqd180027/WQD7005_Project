import pandas as pd
import os

# Set working directory
os.chdir('C:/wqd180027')

# Read CSV into dataframe
df = pd.read_csv("output/merge_data3.csv", index_col=0)

# Function to assign target value, if ChgPct < 0 then 'down',if == 0 then 'no chg',  if > 0 then 'up'
def tgt_value(flt_chgpct):
    if flt_chgpct < 0:
        flt_tgt = 0
    elif flt_chgpct == 0:
        flt_tgt = 0
    else:
        flt_tgt = 1
    return float(flt_tgt)

# Apply function to create Target from ChgPct of respective stocks and create new column
df['AIRASIA_tgt'] = df['AIRASIA_pctchg'].apply(tgt_value)
df['SAPNRG_tgt'] = df['SAPNRG_pctchg'].apply(tgt_value)
df['GETS_tgt'] = df['GETS_pctchg'].apply(tgt_value)
df['MYEG_tgt'] = df['MYEG_pctchg'].apply(tgt_value)

# Save to CSV
df.to_csv("output/merge_data_tgt.csv")

print("hello world")