import pandas as pd
import os
import matplotlib.pyplot as plt
#import numpy as np
from pandas.plotting import scatter_matrix
import seaborn as sns

# Set working directory
os.chdir('C:/wqd180027')

# Read CSV into dataframe
df = pd.read_csv("data/StockPrice_.csv", index_col=0)

# Find unique values and allocate subset of Quote and Codes attribute
unique_quotes = df['Quote'].unique()                # find unique quotes
subset_codes = df[df['Quote'].isin(unique_quotes)]
subset_codes = subset_codes[['Quote','Code']]
subset_codes = subset_codes.drop_duplicates()       # drop duplicates, keep only unique Quotes
sub_sort_codes = subset_codes.sort_values(by='Quote')

# Save Quote and Code subset to CSV
sub_sort_codes.to_csv('data/stock_quote_code.csv')

# Read Business news data into df
df_biz = pd.read_csv("data/BusinessNews_.csv", index_col=0)

def find_quote(code_str):
    temp_find_quote = sub_sort_codes.loc[sub_sort_codes['Code'] == code_str]
    found_quote = temp_find_quote.loc[temp_find_quote['Code']==code_str, 'Quote'].values[0]
    return found_quote


df_biz['Quote'] = df_biz['Code'].apply(find_quote)
df_biz.to_csv("data/BusinessNews_.csv")
# # Pivot data
# pivot_biznews = df_biz.pivot_table(index='Date', columns='Quote', values='Title', aggfunc=len, fill_value=0)
#
# # Save pivots to CSV
# pivot_biznews.to_csv('data/pivot_biznews.csv')

print("hello world")