# Data cleaning Part 2

import pandas as pd
import os

# Set working directory
os.chdir('C:/wqd180027')

# Indices data which was missing (>30% missing) was manually added as python code for automation was taking too long.
# Automation possible but will need more experience with Python coding. At the moment, missing data updated with accurate data
df = pd.read_csv("output/merge_data2.csv", index_col=0)

# Which columns have null values
col_nan = df.columns[df.isna().any()].tolist()
print(col_nan)

# Show number of null values for affected columns
print(df[col_nan].isnull().sum())

# Show percent of null in each column
print(df[col_nan].isnull().sum()*100/len(df[col_nan]))

# Columns with >30% missing data not suitable. Will need to find data
# Since data size is small,
# Manually filled indices data by finding historical data and fill up corresponding to the dates.
# Fill remaining null columns with mean of each column
df = df.fillna(df.mean())

# Rename columns
df = df.rename(columns={'AIRASIA': 'AIRASIA_pctchg',
                        'SAPNRG': 'SAPNRG_pctchg',
                        'GETS': 'GETS_pctchg',
                        'MYEG': 'MYEG_pctchg'})


# Save to merge_data3.csv
df.to_csv("output/merge_data3.csv")


print("Hello World")