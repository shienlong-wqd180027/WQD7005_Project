# -*- coding: utf-8 -*-
"""
Created on Sat Mar 16 16:00:09 2019
crawl only main page of stock posts
in klseinvestor. outputs df
@author: VK
"""
import requests
import pandas as pd
import lxml.html as lh
import re
from pandas_gbq import to_gbq
from google.oauth2 import service_account

header = {'User-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
timestamp = pd.Timestamp.utcnow()
df = pd.DataFrame(columns=['UpdateDate','StockName','Posts'])
count = 0

for i in range(1,50):
    #time.sleep(1)
    url = "https://klse.i3investor.com/jsp/scl/forum.jsp?fp="+str(i)+"&c=1"
    page = requests.get(url, headers=header)
    root = lh.fromstring(page.content)
    table = lh.tostring(root.xpath("//div//table[@id='mainforum']")[0])
    scrapdf = pd.read_html(table, header=0)[0]
    
    for s,p in zip(scrapdf['Discussion Threads'], scrapdf['Posts']):
        try:
            stockname = re.search(":\s*\[(.*)\]\s*:",s).group(1)
            df.loc[count] = [timestamp, stockname, p]
            count+=1
        except:
            continue


## Insert into GBQ
if len(df) > 0:
    
    project_id = 'datamining-118118'
    dataset_id = 'Stocks'
    table_id = 'ForumPosts'
    
    ## Define schema
    schema = [{'name': 'UpdateDate', 'type': 'TIMESTAMP'},
              {'name': 'Quote', 'type': 'STRING'},
              {'name': 'Posts', 'type': 'INTEGER'}]

    ## Name columns
    cols = ['UpdateDate', 'Quote', 'Posts']

    cred = service_account.Credentials.from_service_account_file (
        'gbqadminsa-datamining.json',
    )

    #insert into BQ
    to_gbq( df, project_id = project_id,
        destination_table = dataset_id + "." + table_id,
        if_exists = 'append',
        table_schema=schema,
        credentials  = cred)