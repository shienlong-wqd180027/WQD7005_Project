# Adapted from Yong's initial version
# !/usr/bin/env python3
import requests
import lxml.html as lh
import pandas as pd
import datetime as dt


def ScrapMyStock():  # scrapper for MalaysiaStocks.biz

    ## Initialize variables
    letters = list('3ABCDEFGHIJKLMNOPQRSTUVWXYZ')
    companies = pd.DataFrame()

    ## loop over multiple HTML pages
    for p in letters:
        ## construct the URL request that loops through multiple pages
        ## HTTP get the url returning string
        url = 'https://www.malaysiastock.biz/Listed-Companies.aspx'
        PARAMS = {'value': p, 'type': 'A'}
        page = requests.get(url, params=PARAMS)
        ## Parse the page into lxml object
        ## extract only desired section (html table) and convert to string
        root = lh.fromstring(page.content)
        table = lh.tostring(root.xpath('//*[@id="MainContent_tStock"]')[0])

        ## convert the 'first found' html table string into dataframe
        ## merge them into final dataframe
        srapdf = pd.read_html(table, header=0)[0]
        frames = [companies, srapdf]
        companies = pd.concat(frames, ignore_index=True)

    ## Split Company into 3 columns
    companies[['Quote', 'Code', 'Name']] = companies.Company.str.extract('(.*?)\s\((.*?)\)(.*)', expand=True)

    ## Convert '-' to None, then numbers
    cols = ['PE', 'ROE']
    for i in cols:
        companies[i] = companies[i].replace({'-': None}).astype(float)

    ## MarketCap variable treatment, Convert '-' to None, then Convert b to '000 then integer
    num_replace = {  ## Convert B to '000
        'b': 'e3',
        'm': 'e0',
    }

    def str_to_num(s):  # standardize unit in 'million'
        if s == None: return None
        if s[-1] in num_replace:
            s = s[:-1] + num_replace[s[-1]]
        return int(float(s))

    companies['Market Cap'] = companies['Market Cap'].replace({'-': None})
    companies['Market Cap'] = companies['Market Cap'].apply(str_to_num)

    ## Reformat, Rename Cols before returning
    companies = companies.replace({pd.np.nan: None})  # convert NaN to none, otherwise GBQ insert will fail
    companies = companies.rename(columns={'Last Price': 'LastPrice',
                                          'Market Cap': 'MarketCap'})  # convert NaN to none, otherwise GBQ insert will fail
    cols = ['Quote', 'Code', 'Name', 'Sector', 'MarketCap', 'LastPrice', 'PE', 'DY', 'ROE']
    return companies[cols]


def ScrapTheStar(quotes):  # scapper for TheStar.com

    ## initialize vars
    companies = pd.DataFrame()

    ## Loop through each quote page, build the dataframe
    for q in quotes:
        url = 'https://www.thestar.com.my/business/marketwatch/stocks/'
        PARAMS = {'qcounter': q}
        page = requests.get(url, params=PARAMS)
        root = lh.fromstring(page.content)
        table = lh.tostring(root.xpath('//*[@id="slcontent_0_ileft_0_info"]/table')[0])
        srapdf = pd.read_html(table, header=0)[0]
        frames = [companies, srapdf]
        companies = pd.concat(frames, ignore_index=True)
        # if q == 'ADVPKG': break

    ## naming quote, needed for joinining
    companies['Quote'] = quotes

    ## Split Buy and Sell columns
    companies[['BuyAt', 'BuyVol']] = companies["Buy/Vol ('00)"].str.extract('(.*?)\s/\s(.*?$)', expand=True)
    companies[['SellAt', 'SellVol']] = companies["Sell/Vol ('00)"].str.extract('(.*?)\s/\s(.*?$)', expand=True)

    ## Convert '- to None, then convert to number
    cols = ['Open', 'Low', 'High']
    for i in cols:
        companies[i] = companies[i].replace({'-': None}).astype(float)

    ## Remove comma, then convert to number,
    cols = ['BuyAt', 'BuyVol', 'SellAt', 'SellVol']
    for i in cols:
        companies[i] = companies[i].str.replace(',', '').astype(float)

    ## Reformat DataFrame before returning
    companies = companies.replace({pd.np.nan: None})  # convert NaN to none, otherwise GBQ insert will fail
    companies.rename(columns={"Vol ('00)": 'Volume', 'Chg %': 'Chg%'}, inplace=True)
    cols = ['Quote', 'Open', 'Low', 'High', 'Chg', 'Chg%', 'Volume', 'BuyAt', 'BuyVol', 'SellAt', 'SellVol']
    return companies[cols]


### Let's Run It
########################################################################

df1 = ScrapMyStock()  # get first df
df2 = ScrapTheStar(df1.Quote)  # get second df
df_final = pd.merge(df1, df2, on='Quote')  # join both df

## GBQ Connections and Parameters
project_id = 'datamining-118118'
dataset_id = 'Stocks'
table_id   = 'StockPrice'
destination_table = dataset_id + "." + table_id

cred = service_account.Credentials.from_service_account_file (
    'gbqadminsa-datamining.json',
)
to_gbq( df, project_id = project_id,
        destination_table = destination_table,
        if_exists = 'append',
        credentials  = cred)