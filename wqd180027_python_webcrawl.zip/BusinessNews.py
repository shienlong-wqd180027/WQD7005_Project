# -*- coding: utf-8 -*-
"""
Created on Sun Feb 24 18:48:36 2019
scrape rss feed for general business news and malaysiastock.biz for stock specific headlines
creates 2 dataframes: rssDF and newsDF ->merged into finalDF
@author: VK
"""

import feedparser                               # downloading and parsing syndicated feeds
from dateutil.parser import parse
import requests                                 # send HTTP/1.1 requests using Python
import lxml.html as lh                          # Python package for dealing with HTML
import pandas as pd                             # data structures for data analysis, time series,and statistics
import datetime                                 # manipulating dates and times
from pandas_gbq import to_gbq                   # interface to the Google BigQuery API from pandas
from google.oauth2 import service_account       # authorization protocol used by Google APIs

def getrss(url):
    newsfeed = feedparser.parse(url)
    result = newsfeed.entries
    return result

def getnews(stocknum, news_url):
    url=news_url+stocknum
    page=requests.get(url)
    root=lh.fromstring(page.content)
    charset='iso-8859-1'
    #table=lh.tostring(root.xpath('//*[@id="ctl17_tbCorpHeadline"]')[0], encoding='iso-8859-1')
    
    try:
        tblink = root.xpath('//*[@id="ctl17_tbCorpHeadline"]')[0]
        date = [l.encode(charset).decode('utf8') for l in tblink.xpath('//tr[@class="line"]//td/text()')]
        title = [l.xpath('text()')[0].encode(charset).decode('utf8') for l in tblink.xpath('//tr[@class="line"]//a[contains(@href,"newsID")]')]
        href = [l.encode(charset).decode('utf8') for l in tblink.xpath('//tr[@class="line"]//a[contains(@href,"newsID")]/@href')]
        print('INFO: Getting stock ',stocknum)
        stack=[[stocknum,x,y,z] for x,y,z in zip(date, title, href)]
        df=pd.DataFrame(stack, columns=['Code' ,'UpdateDate','Title','Link'])
    #some stock codes don't exist or the page exists but there are no news items
    #in this case, return empty dataframe and print error
    except:
        df=pd.DataFrame(columns=['Code','UpdateDate','Title','Link'])
        print("ERROR: could not get news items for %s" %stocknum)
    return df

#def main():
    
output_to_csv = False
rss_source = {'thestarbusiness':'http://www.thestar.com.my/rss/business/business-news/', # aggregated news source
          'malaysiakini':'https://www.malaysiakini.com/en/columns.rss',
          'theedge':'http://www.theedgemarkets.com/mymalaysia.rss',
          'sunbusiness':'https://www.thesundaily.my/rss/business'}

news_url = 'https://www.malaysiastock.biz/Corporate-Infomation.aspx?securityCode='
stocklist_df=pd.read_csv('stockinfo.csv')
today = datetime.date.today()
timestamp = pd.Timestamp.utcnow()

#initialize main variables
all_rss = []
rssDF = pd.DataFrame(columns=['Code','UpdateDate','Title','Link'])
newsDF = pd.DataFrame(columns=['Code','UpdateDate','Title','Link']) # for sites without RSS feeds

#get rss news and only keep those that are from current date
for source in rss_source.keys():
    for item in getrss(rss_source[source]):
        print('INFO: Getting rss from ',rss_source[source])
        if parse(item['published']).date()==today:
            all_rss.append(item)
        
#save all_rss into rssDF dataframe
for i in range(0,len(all_rss)):
    rssDF.loc[i] = [None ,timestamp ,all_rss[i]['title'],all_rss[i]['links'][0]['href']]

#get news headlines for each stock code
for code in list(stocklist_df['Code']):
    if code == '5099': break
    tmpdf = getnews(str(code),news_url)
    for i in range(0, len(tmpdf['UpdateDate'])):
        if list(tmpdf['UpdateDate'])[i]==today.strftime('%d %b'):
            tmpdf['UpdateDate'][i] = timestamp
            newsDF = newsDF.append(tmpdf.iloc[[i]])

#enable output to csv
if output_to_csv:
    tdate = datetime.date.today().isoformat()
    filename1 = 'rss-'+str(tdate)+'.csv'
    filename2 = 'stocknews-'+str(tdate)+'.csv'
    rssDF.to_csv(filename1, encoding='utf-8', index=False)
    newsDF.to_csv(filename2, encoding='utf-8', index=False)

## Combine both RSS and News Into one DataFrame
frames    = [rssDF, newsDF]
df = pd.concat(frames, ignore_index=True)
df['UpdateDate'] = pd.Timestamp.utcnow()   #timestamp
df['UpdateDate'] = df.UpdateDate.astype('datetime64[ms]') #convert type from object to datetime64

## GBQ Connections and Parameters
project_id = 'datamining-118118'
dataset_id = 'Stocks'
table_id   = 'BusinessNews'
destination_table = dataset_id + "." + table_id 

cred = service_account.Credentials.from_service_account_file (
    'gbqadminsa-datamining.json',
)
to_gbq( df, project_id = project_id,
        destination_table = destination_table,
        if_exists = 'append',
        credentials  = cred)

#if __name__=='__main__':
#    main()