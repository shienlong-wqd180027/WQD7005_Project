# Adapted from Yong's initial version
# !/usr/bin/env python3
import requests
import lxml.html as lh
import pandas as pd
from pandas_gbq import to_gbq
from google.oauth2 import service_account


def Forex():
    # Scrape data from url and place in df
    url = 'https://finance.yahoo.com/currencies'
    page = requests.get(url)
    root = lh.fromstring(page.content)
    table = lh.tostring(root.xpath('//*[@id="yfin-list"]/div[2]/div/div/table')[0])
    df3 = pd.read_html(table, header=0)[0]

    ## Volume variable treatment, Convert b to '000 then integer
    # num_replace = {  ## Convert B to '000
    #     'B': 'e3',
    #     'M': 'e0',
    # }

    # def str_to_num(s):  # standardize unit in 'million'
    #     if s == None: return None
    #     if s[-1] in num_replace:
    #         s = s[:-1] + num_replace[s[-1]]
    #     return float(s)

    # df3['Volume'] = df3['Volume'].apply(str_to_num)

    ## Remove % in '% Change' variable
    df3['% Change'] = df3['% Change'].str.replace('%', '')

    ## Rename columns and change data type
    df3.rename(columns={'Last Price': 'LastPrice'}, inplace=True)
    df3.rename(columns={'% Change': 'ChgPct'}, inplace=True)

    ## Type To Number Conversion
    df3['ChgPct'] = df3['ChgPct'].astype(float)

    ## Remove empty columns
    cols = ['Symbol', 'Name', 'LastPrice', 'Change', 'ChgPct']
    df3 = df3[cols]

    ## Remove rows not related to USD/MYR
    df3 = df3[df3.Name == 'USD/MYR']

    # ## Create Timestamp
    # df3['UpdateDate'] = pd.Timestamp.utcnow()  # timestamp
    # df3['UpdateDate'] = df3.UpdateDate.astype('datetime64[ms]')  # convert type from object to datetime64

    ## Define schema
    schema = [{'name': 'Symbol', 'type': 'STRING'},
              {'name': 'Name', 'type': 'STRING'},
              {'name': 'LastPrice', 'type': 'FLOAT'},
              {'name': 'Change', 'type': 'FLOAT'},
              {'name': 'ChgPct', 'type': 'FLOAT'},
              {'name': 'UpdateDate', 'type': 'TIMESTAMP'}]

    ## Create Timestamp
    df3['UpdateDate'] = pd.Timestamp.utcnow()  # timestamp

    ## Name columns
    cols = ['Symbol', 'Name', 'LastPrice', 'Change', 'ChgPct', 'UpdateDate']

    ## Upload to GBQ
    project_id = 'datamining-118118'
    dataset_id = 'Stocks'
    table_id = 'Forex'
    destination_table = dataset_id + "." + table_id

    cred = service_account.Credentials.from_service_account_file(
        'gbqadminsa-datamining.json',
    )
    to_gbq(df3[cols], project_id=project_id,
           destination_table=destination_table,
           if_exists='append',
           table_schema=schema,
           credentials=cred)


def main():
    Forex()


main()