# Adapted from Yong's initial version
# !/usr/bin/env python3
import requests
import lxml.html as lh
import pandas as pd

from pandas_gbq import to_gbq
from pandas_gbq import read_gbq
from google.oauth2 import service_account
from twython import Twython

def ScrapMyStock():  # scrapper for MalaysiaStocks.biz

    ## Initialize variables
    letters = list('3ABCDEFGHIJKLMNOPQRSTUVWXYZ')
    #letters = list('3A')
    
    companies = pd.DataFrame()

    ## loop over multiple HTML pages
    for p in letters:
        ## construct the URL request that loops through multiple pages
        ## HTTP get the url returning string
        url = 'https://www.malaysiastock.biz/Listed-Companies.aspx'
        PARAMS = {'value': p, 'type': 'A'}
        page = requests.get(url, params=PARAMS)
        ## Parse the page into lxml object
        ## extract only desired section (html table) and convert to string
        root = lh.fromstring(page.content)
        table = lh.tostring(root.xpath('//*[@id="MainContent_tStock"]')[0])

        ## convert the 'first found' html table string into dataframe
        ## merge them into final dataframe
        srapdf = pd.read_html(table, header=0)[0]
        frames = [companies, srapdf]
        companies = pd.concat(frames, ignore_index=True)

    ## Split Company into 3 columns
    companies[['Quote', 'Code', 'Name']] = companies.Company.str.extract('(.*?)\s\((.*?)\)(.*)', expand=True)

    ## Convert '-' to None, then numbers
    cols = ['PE', 'ROE']
    for i in cols:
        companies[i] = companies[i].replace({'-': None}).astype(float)

    ## MarketCap variable treatment, Convert '-' to None, then Convert b to '000 then integer
    num_replace = {  ## Convert B to '000
        'b': 'e3',
        'm': 'e0',
    }

    def str_to_num(s):  # standardize unit in 'million'
        if s == None: return None
        if s[-1] in num_replace:
            s = s[:-1] + num_replace[s[-1]]
        return int(float(s))

    companies['Market Cap'] = companies['Market Cap'].replace({'-': None})
    companies['Market Cap'] = companies['Market Cap'].apply(str_to_num)

    ## Reformat, Rename Cols before returning
    companies = companies.replace({pd.np.nan: None})  # convert NaN to none, otherwise GBQ insert will fail
    companies = companies.rename(columns={'Last Price': 'LastPrice',
                                          'Market Cap': 'MarketCap'})  # convert NaN to none, otherwise GBQ insert will fail
    cols = ['Quote', 'Code', 'Name', 'Sector', 'MarketCap', 'LastPrice', 'PE', 'DY', 'ROE']
    return companies[cols]



def ScrapTweets(quotesDF):
    
    ## initialize vars
    tweets = pd.DataFrame([], columns = ['Quote', 'Date', 'TweetFullText', 'ReTweetCount', 'FavoriteCount', 'ID'])

    twitter = Twython('BiqNFiTnYLGxlV7ysFHn75TKe', 'HaX8s6kjJQyngl66wgtnagkqubzXSIc1UTs9AmNEobZIg64OnU',
                  '64235844-2WETYggByFwH1ysWl8P9BvKQlM5tKHQStquhBeOgx', 'Ds4P61ZPzBA3mxzNr6TKVuXsWFpaEl5QIGMTfrbVPH6Nl')
    
    try:
        
        #  BQ initialization
        project_id = 'datamining-118118'
        dataset_id = 'Stocks'
        table_id   = 'StocksTweetFeed'
        destination_table = dataset_id + "." + table_id 
        
        cred = service_account.Credentials.from_service_account_file (
            'gbqadminsa-datamining.json',
        )
        
        # default since_id to use
        SinceID = '1099010461440315394'
        
        ## read all existing enteries and find since_id to use
        sql = 'SELECT  max(ID) MaxID, Quote FROM Stocks.StocksTweetFeed group by Quote'        
        MaxQuoteIDs = read_gbq(sql, project_id=project_id, credentials=cred)           
       
        ## Loop through each quote page, build the dataframe
        for index, row in quotesDF.iterrows():
                        
            SinceIDlocal = SinceID
            
            # does entry exists already, if yes.. choose the max since_id
            if (len(MaxQuoteIDs.loc[MaxQuoteIDs.Quote == row['Quote']]) > 0):
                #print(MaxQuoteIDs.loc[MaxQuoteIDs.Quote == row['Quote'], 'MaxID'].iloc[0].astype(str))
                SinceIDlocal = MaxQuoteIDs.loc[MaxQuoteIDs.Quote == row['Quote'], 'MaxID'].iloc[0].astype(str)
                        
            ##print(row['Quote'], row['Name'])    
            searchString = '%24' + row['Quote'] ##+ ' OR ' + row['Name']
                        
            # load the search results
            results = twitter.cursor(twitter.search, q= searchString, since_id=SinceIDlocal)            
            
            # iterate and save to BQ
            count=0
            
            try:
                for result in results:   
                    print(result["created_at"], result["text"])
                    count +=1
                    
                    tweetRow = {'Quote':row['Quote'],'Date':result["created_at"],'TweetFullText':result["text"], 'ReTweetCount':result["retweet_count"], 'FavoriteCount':result["favorite_count"] , 'ID':result["id"]}
                    tweets = tweets.append(tweetRow, ignore_index=True)
                    
                    # limit, else difficult to control for few stocks
                    if count == 10:
                        break
                    
            except Exception as e:
               print('No More tweets. ' + str(e)) 
               
        # convert date
        tweets['Date'] = tweets.Date.astype('datetime64[ms]') #convert type from object to datetime64
        tweets['Quote'] = tweets['Quote'].astype(str)
        tweets['ReTweetCount'] = tweets['ReTweetCount'].astype(int)
        tweets['FavoriteCount'] = tweets['FavoriteCount'].astype(int)
        tweets['ID'] = tweets['ID'].astype('int64')
        tweets['TweetFullText'] = tweets['TweetFullText'].astype(str)
        
        # print(len(tweets.index))
        
        if len(tweets.index) > 0:
            # insert into BQ
            to_gbq( tweets, project_id = project_id,
                destination_table = destination_table,
                if_exists = 'append',
                credentials  = cred)
        
    except Exception as e:
           print(str(e))
        
    
    return tweets    

### Let's Run It
########################################################################

df1 = ScrapMyStock()  # get first df
dfTweet = ScrapTweets(df1)
# df2 = ScrapTheStar(df1.Quote)  # get second df
# df_final = pd.merge(df1, df2, on='Quote')  # join both df
# df3 = ScrapMajorIndices()  # get third f
